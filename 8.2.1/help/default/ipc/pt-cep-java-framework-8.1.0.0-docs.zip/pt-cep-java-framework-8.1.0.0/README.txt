Using the Packet Tracer 5 Java CEP

The Java CEP is packaged as an archive file containing the CEP library, documentation, and sample code. If you
look at the structure of the archive you'll see pt-cep-java-framework-5.0-beta-4.jar, the code library file. You'll
also see the following directories:

/conf - contains sample log4j and pt_cep properties files. The pt_cep.properties file is where the developer
defines connection parameters and strings used for authentication. However, if it's missing the framework falls back
to default values that work.

/doc  - contains the Javadocs for the API and test reports.

/examples - contains sample code that demonstrates how to make calls to Packet Tracer. If you're looking for a
quick start to using the Java CEP framework, these are worth a read.

/lib - contains libraries required by the Java CEP framework.

To use the Java CEP, you must have a working instance of Packet Tracer 5.0 installed. If you want to launch
Packet Tracer from within your Java application, you'll need to make sure Packet Tracer is on the system path,
or that the environment variable "PT5HOME" is set, and points to the base directory of the Packet Tracer
installation.

To set up your development environment, start by unpacking the CEP distribution. Take some time getting
acquainted with the documentation, then examine the sample applications to see how to create a Packet Tracer
session and use it to call Packet Tracer IPC functions.

The CEP uses default values for encryption, compression and encoding in the Packet Tracer connection, but you
can customize these by following the examples in the sample pt_cep.properties file. This file must reside on
the class path, or you must give a fully qualified path name for the CEP code to locate it.

Use the BuildFramework.bat batch script to build it in windows.